"use client"

import { useState, useCallback } from "react"

interface CacheEntry<T> {
  data: T
  timestamp: number
  ttl: number
}

interface CacheOptions {
  defaultTTL?: number
}

export function useCache<T>(options: CacheOptions = {}) {
  const { defaultTTL = 5 * 60 * 1000 } = options // 5 minutes default
  const [cache, setCache] = useState<Map<string, CacheEntry<T>>>(new Map())

  const isExpired = useCallback((entry: CacheEntry<T>): boolean => {
    return Date.now() - entry.timestamp > entry.ttl
  }, [])

  const get = useCallback(
    (key: string): T | null => {
      const entry = cache.get(key)
      if (!entry) return null

      if (isExpired(entry)) {
        setCache((prev) => {
          const newCache = new Map(prev)
          newCache.delete(key)
          return newCache
        })
        return null
      }

      return entry.data
    },
    [cache, isExpired],
  )

  const set = useCallback(
    (key: string, data: T, ttl: number = defaultTTL) => {
      setCache((prev) => {
        const newCache = new Map(prev)
        newCache.set(key, {
          data,
          timestamp: Date.now(),
          ttl,
        })
        return newCache
      })
    },
    [defaultTTL],
  )

  const remove = useCallback((key: string) => {
    setCache((prev) => {
      const newCache = new Map(prev)
      newCache.delete(key)
      return newCache
    })
  }, [])

  const clear = useCallback(() => {
    setCache(new Map())
  }, [])

  const has = useCallback(
    (key: string): boolean => {
      const entry = cache.get(key)
      if (!entry) return false

      if (isExpired(entry)) {
        setCache((prev) => {
          const newCache = new Map(prev)
          newCache.delete(key)
          return newCache
        })
        return false
      }

      return true
    },
    [cache, isExpired],
  )

  return { get, set, remove, clear, has }
}
