import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, Users, Shield, MessageCircle } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Tentang Kami</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Confesio dibangun oleh sekelompok pengembang yang percaya bahwa percakapan jujur lebih mudah terjadi ketika
          identitas tidak menjadi beban.
        </p>
      </div>

      <div className="grid gap-6">
        <Card className="border-2 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Heart className="h-6 w-6 text-red-500" />
              <CardTitle>Visi Kami</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-relaxed">
              Kami menyediakan cara cepat untuk berinteraksi: ketik nama panggilan, pilih ruang publik, lalu mulai
              berbicara secara real-time. Kami meminimalkan pengumpulan data demi menjaga suasana tetap aman dan
              inklusif.
            </p>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-2 border-primary/20">
            <CardHeader>
              <Shield className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Keamanan</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Privasi dan keamanan adalah prioritas utama kami dalam setiap fitur yang dikembangkan.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-primary/20">
            <CardHeader>
              <MessageCircle className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Komunikasi</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Memfasilitasi percakapan yang bermakna tanpa hambatan identitas atau prasangka.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-primary/20">
            <CardHeader>
              <Users className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Komunitas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Membangun ruang yang aman dan inklusif untuk semua orang berbagi pemikiran.
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-2 border-primary/20">
          <CardHeader>
            <CardTitle>Masukan Anda</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-relaxed">
              Masukan apa pun sangat kami hargai. Kami terus berupaya meningkatkan platform ini berdasarkan kebutuhan
              dan saran dari komunitas pengguna.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
