import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Mail, Clock, Shield, MessageCircle, Users, Plus } from "lucide-react"

export default function HelpPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Bantuan</h1>
        <p className="text-muted-foreground text-lg">Butuh bantuan? Kami siap membantu Anda.</p>
      </div>

      <div className="grid gap-6">
        <Card className="border-2 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Mail className="h-6 w-6 text-primary" />
              <CardTitle>Hubungi Kami</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              Jika Anda mengalami masalah teknis, ingin melaporkan kerentanan, atau meminta penghapusan data, kirim
              email ke:
            </p>
            <Button asChild>
              <a href="mailto:confesiocs@gmail.com" className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span>confesiocs@gmail.com</span>
              </a>
            </Button>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>Tim dukungan berusaha membalas dalam waktu dua hari kerja.</span>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-2 border-primary/20">
            <CardHeader>
              <div className="flex items-center space-x-2">
                <Users className="h-6 w-6 text-primary" />
                <CardTitle>Cara Membuat Profil</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>Klik "Buat Profil" di halaman utama</li>
                <li>Masukkan nama pengguna unik</li>
                <li>Pilih avatar dan warna tema</li>
                <li>Profil Anda siap digunakan!</li>
              </ol>
            </CardContent>
          </Card>

          <Card className="border-2 border-primary/20">
            <CardHeader>
              <div className="flex items-center space-x-2">
                <Plus className="h-6 w-6 text-primary" />
                <CardTitle>Cara Membuat Room</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>Klik "Buat Room" di navigasi</li>
                <li>Berikan nama dan deskripsi room</li>
                <li>Pilih kategori yang sesuai</li>
                <li>Room publik Anda akan tersedia untuk semua</li>
              </ol>
            </CardContent>
          </Card>

          <Card className="border-2 border-primary/20">
            <CardHeader>
              <div className="flex items-center space-x-2">
                <MessageCircle className="h-6 w-6 text-primary" />
                <CardTitle>Cara Mengirim Pesan</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>Masuk ke room atau profil yang diinginkan</li>
                <li>Ketik pesan di kolom input</li>
                <li>Tekan Enter atau klik tombol kirim</li>
                <li>Pesan akan muncul secara real-time</li>
              </ol>
            </CardContent>
          </Card>

          <Card className="border-2 border-primary/20">
            <CardHeader>
              <div className="flex items-center space-x-2">
                <Shield className="h-6 w-6 text-primary" />
                <CardTitle>Keamanan & Privasi</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Tidak perlu email atau password</li>
                <li>Semua komunikasi dienkripsi</li>
                <li>Data minimal yang dikumpulkan</li>
                <li>Anonimitas terjaga sepenuhnya</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
