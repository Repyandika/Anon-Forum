import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, AlertTriangle, Users, Shield } from "lucide-react"

export default function TermsPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Syarat Layanan</h1>
        <p className="text-muted-foreground text-lg">Berlaku sejak tanggal Confesio pertama kali dirilis untuk umum.</p>
      </div>

      <div className="grid gap-6">
        <Card className="border-2 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <FileText className="h-6 w-6 text-primary" />
              <CardTitle>Tentang Layanan</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-relaxed">
              Confesio adalah layanan ruang obrolan anonim berbasis web.
            </p>
          </CardContent>
        </Card>

        <Card className="border-2 border-destructive/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-6 w-6 text-destructive" />
              <CardTitle>Konten yang Dilarang</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-relaxed">
              Pengguna dilarang mengirim konten ilegal, ujaran kebencian, promosi kekerasan, eksploitasi anak, spam,
              atau materi yang melanggar hak cipta.
            </p>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Users className="h-6 w-6 text-primary" />
              <CardTitle>Tanggung Jawab Pengguna</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              Konten pesan sepenuhnya menjadi tanggung jawab pengirim. Confesio tidak bertanggung jawab atas, dan tidak
              memiliki kewajiban untuk memantau, meninjau, atau menyunting konten apa pun yang diposting pengguna.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Pengguna memberikan lisensi non-eksklusif kepada Confesio untuk menampilkan dan menyimpan pesan selama
              sesi berlangsung.
            </p>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Shield className="h-6 w-6 text-primary" />
              <CardTitle>Hak Platform</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              Confesio berhak menangguhkan atau menghapus profil yang melanggar ketentuan tanpa pemberitahuan.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Layanan disediakan apa adanya. Confesio tidak menjamin ketersediaan tanpa gangguan dan tidak bertanggung
              jawab atas kerugian langsung maupun tidak langsung yang timbul dari penggunaan platform.
            </p>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/20">
          <CardHeader>
            <CardTitle>Persetujuan</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              Dengan mengakses dan menggunakan website Confesio, Anda menyatakan telah membaca, memahami, dan sepenuhnya
              menyetujui Syarat Layanan serta Kebijakan Privasi.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Syarat Layanan dapat diperbarui sewaktu-waktu. Versi terbaru akan dipublikasikan di situs dan berlaku
              segera.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
