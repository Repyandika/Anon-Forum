import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Lock, Eye, Database } from "lucide-react"

export default function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Kebijakan Privasi</h1>
        <p className="text-muted-foreground text-lg">Berlaku sejak tanggal Confesio pertama kali dirilis untuk umum.</p>
      </div>

      <div className="grid gap-6">
        <Card className="border-2 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Shield className="h-6 w-6 text-primary" />
              <CardTitle>Komitmen Privasi</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              Confesio berkomitmen melindungi privasi setiap pengguna. Saat Anda membuat profil anonim, satu-satunya
              data identitas yang kami minta adalah nama pengguna. Kami tidak meminta alamat email, nomor telepon, atau
              kata sandi.
            </p>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Database className="h-6 w-6 text-primary" />
              <CardTitle>Data yang Kami Kumpulkan</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              Server kami mencatat data teknis nonpribadi, misalnya jenis peramban, zona waktu, dan alamat IP yang telah
              dianonimkan. Informasi tersebut digunakan untuk tiga tujuan: menjalankan fitur obrolan secara andal,
              memperbaiki performa layanan, dan mencegah penyalahgunaan.
            </p>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Lock className="h-6 w-6 text-primary" />
              <CardTitle>Perlindungan Data</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              Kami tidak menjual atau menyewakan data pribadi kepada pihak mana pun. Seluruh lalu lintas dilindungi enkripsi TLS dan akses ke infrastruktur dibatasi
              secara ketat.
            </p>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Eye className="h-6 w-6 text-primary" />
              <CardTitle>Perubahan Kebijakan</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              Jika kebijakan ini berubah, pemberitahuan akan muncul di halaman utama. Dengan terus menggunakan Confesio,
              Anda dianggap memahami dan menyetujui Kebijakan Privasi ini.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
