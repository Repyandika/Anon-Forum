import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  try {
    const { messageId, messageType, content, senderNickname, imageUrl } = await request.json()

    if (!messageId || !messageType || (!content?.trim() && !imageUrl)) {
      return NextResponse.json({ error: "Message ID, type, and content or image are required" }, { status: 400 })
    }

    // Determine the correct table and column based on message type
    const tableName = messageType === "profile" ? "message_replies" : "room_message_replies"
    const messageColumn = messageType === "profile" ? "message_id" : "room_message_id"

    const { data, error } = await supabase
      .from(tableName)
      .insert([
        {
          [messageColumn]: messageId,
          content: content?.trim() || null,
          sender_nickname: senderNickname?.trim() || null,
          image_url: imageUrl || null,
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Supabase error:", error)
      return NextResponse.json({ error: "Failed to post reply" }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Error posting reply:", error)
    return NextResponse.json({ error: "Failed to post reply" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const messageId = searchParams.get("messageId")
    const messageType = searchParams.get("messageType")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    if (!messageId || !messageType) {
      return NextResponse.json({ error: "Message ID and type are required" }, { status: 400 })
    }

    // Determine the correct table and column based on message type
    const tableName = messageType === "profile" ? "message_replies" : "room_message_replies"
    const messageColumn = messageType === "profile" ? "message_id" : "room_message_id"

    // Calculate offset
    const offset = (page - 1) * limit

    // Get total count
    const { count, error: countError } = await supabase
      .from(tableName)
      .select("*", { count: "exact", head: true })
      .eq(messageColumn, messageId)

    if (countError) {
      console.error("Count error:", countError)
      return NextResponse.json({ error: "Failed to fetch reply count" }, { status: 500 })
    }

    // Get paginated replies
    const { data: replies, error } = await supabase
      .from(tableName)
      .select("*")
      .eq(messageColumn, messageId)
      .order("created_at", { ascending: true })
      .range(offset, offset + limit - 1)

    if (error) {
      console.error("Replies error:", error)
      return NextResponse.json({ error: "Failed to fetch replies" }, { status: 500 })
    }

    return NextResponse.json({
      replies: replies || [],
      total: count || 0,
      page,
      totalPages: Math.ceil((count || 0) / limit),
    })
  } catch (error) {
    console.error("Error fetching replies:", error)
    return NextResponse.json({ error: "Failed to fetch replies" }, { status: 500 })
  }
}
