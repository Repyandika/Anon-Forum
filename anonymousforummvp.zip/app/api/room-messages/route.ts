import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

/**
 * Utility – if Supabase is unreachable (e.g. in Next.js) just
 * return a safe empty payload so the UI continues to work.
 */
function supabaseOfflineResponse() {
  return NextResponse.json({ messages: [], totalPages: 1, totalMessages: 0, currentPage: 1 }, { status: 200 })
}

/* -------------------------------------------------------------------------- */
/* POST – create message                                                      */
/* -------------------------------------------------------------------------- */
export async function POST(request: NextRequest) {
  try {
    const { roomId, content, senderUsername, imageUrl } = await request.json()

    if (!roomId || (!content?.trim() && !imageUrl)) {
      return NextResponse.json({ error: "Room ID and content or image are required" }, { status: 400 })
    }

    const { data, error } = await supabase
      .from("room_messages")
      .insert([
        {
          room_id: roomId,
          content: content?.trim() || null,
          sender_username: senderUsername?.trim() || null,
          image_url: imageUrl || null,
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Supabase POST error:", error)
      return supabaseOfflineResponse()
    }

    return NextResponse.json(data, { status: 201 })
  } catch (err) {
    console.error("POST /room-messages fatal error:", err)
    return supabaseOfflineResponse()
  }
}

/* -------------------------------------------------------------------------- */
/* GET – paginated list                                                       */
/* -------------------------------------------------------------------------- */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const roomId = searchParams.get("roomId")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    if (!roomId) {
      return NextResponse.json({ error: "Room ID is required" }, { status: 400 })
    }

    const offset = (page - 1) * limit

    /* ---------- total count ---------- */
    const { count, error: countError } = await supabase
      .from("room_messages")
      .select("*", { count: "exact", head: true })
      .eq("room_id", roomId)

    if (countError) {
      console.error("Supabase COUNT error:", countError)
      return supabaseOfflineResponse()
    }

    /* ---------- paginated rows ---------- */
    const { data: messages, error } = await supabase
      .from("room_messages")
      .select("*")
      .eq("room_id", roomId)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)

    if (error) {
      console.error("Supabase SELECT error:", error)
      return supabaseOfflineResponse()
    }

    const totalPages = Math.max(1, Math.ceil((count || 0) / limit))

    return NextResponse.json({
      messages: messages || [],
      totalPages,
      totalMessages: count || 0,
      currentPage: page,
    })
  } catch (err) {
    console.error("GET /room-messages fatal error:", err)
    return supabaseOfflineResponse()
  }
}
