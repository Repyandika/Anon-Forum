import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")

    let query = supabase.from("rooms").select("*").eq("is_private", false).order("created_at", { ascending: false })

    if (search) {
      query = query.or(`name.ilike.%${search}%,description.ilike.%${search}%`)
    }

    const { data: rooms, error } = await query

    if (error) {
      console.error("Error fetching rooms:", error)
      return NextResponse.json({ error: "Failed to fetch rooms" }, { status: 500 })
    }

    return NextResponse.json(rooms || [])
  } catch (error) {
    console.error("Error in rooms API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, description } = body

    if (!name?.trim() || !description?.trim()) {
      return NextResponse.json({ error: "Name and description are required" }, { status: 400 })
    }

    const { data: room, error } = await supabase
      .from("rooms")
      .insert([
        {
          name: name.trim(),
          description: description.trim(),
          is_private: false, // Always public
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Error creating room:", error)
      return NextResponse.json({ error: "Failed to create room" }, { status: 500 })
    }

    return NextResponse.json(room, { status: 201 })
  } catch (error) {
    console.error("Error in create room API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
