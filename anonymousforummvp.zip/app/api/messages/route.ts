import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const username = searchParams.get("username")
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")

  if (!username) {
    return NextResponse.json({ error: "Username is required" }, { status: 400 })
  }

  const supabase = createClient()

  try {
    // Get total count
    const { count } = await supabase
      .from("messages")
      .select("*", { count: "exact", head: true })
      .eq("recipient_username", username)

    // Get paginated messages
    const offset = (page - 1) * limit
    const { data: messages, error } = await supabase
      .from("messages")
      .select("*")
      .eq("recipient_username", username)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)

    if (error) {
      console.error("Error fetching messages:", error)
      return NextResponse.json({ error: "Failed to fetch messages" }, { status: 500 })
    }

    const totalPages = Math.ceil((count || 0) / limit)

    return NextResponse.json({
      messages: messages || [],
      totalPages,
      totalMessages: count || 0,
      currentPage: page,
    })
  } catch (error) {
    console.error("Error fetching messages:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { recipientUsername, content, senderNickname } = await request.json()

    if (!recipientUsername || !content) {
      return NextResponse.json({ error: "Recipient username and content are required" }, { status: 400 })
    }

    const supabase = createClient()

    const { data, error } = await supabase
      .from("messages")
      .insert([
        {
          recipient_username: recipientUsername,
          content: content.trim(),
          sender_nickname: senderNickname?.trim() || null,
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Error creating message:", error)
      return NextResponse.json({ error: "Failed to send message" }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Error creating message:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
