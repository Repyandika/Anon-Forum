import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  try {
    const { messageId, messageType, reactionType } = await request.json()

    if (!messageId || !messageType || !reactionType) {
      return NextResponse.json({ error: "Message ID, type, and reaction type are required" }, { status: 400 })
    }

    const tableName = messageType === "profile" ? "message_reactions" : "room_message_reactions"
    const foreignKey = messageType === "profile" ? "message_id" : "room_message_id"

    const { data, error } = await supabase
      .from(tableName)
      .insert([
        {
          [foreignKey]: messageId,
          reaction_type: reactionType,
        },
      ])
      .select()
      .single()

    if (error) throw error

    return NextResponse.json(data)
  } catch (error) {
    console.error("Error adding reaction:", error)
    return NextResponse.json({ error: "Failed to add reaction" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const messageId = searchParams.get("messageId")
    const messageType = searchParams.get("messageType")

    if (!messageId || !messageType) {
      return NextResponse.json({ error: "Message ID and type are required" }, { status: 400 })
    }

    const tableName = messageType === "profile" ? "message_reactions" : "room_message_reactions"
    const foreignKey = messageType === "profile" ? "message_id" : "room_message_id"

    const { data, error } = await supabase
      .from(tableName)
      .select("*")
      .eq(foreignKey, messageId)
      .order("created_at", { ascending: true })

    if (error) throw error

    return NextResponse.json(data || [])
  } catch (error) {
    console.error("Error fetching reactions:", error)
    return NextResponse.json({ error: "Failed to fetch reactions" }, { status: 500 })
  }
}
