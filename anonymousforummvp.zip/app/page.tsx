import Link from "next/link"
import { ConfessioLogo } from "@/components/confessio-logo"
import { RoomList } from "@/components/rooms/room-list"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageSquare, Users, Plus, Shield, Moon, Sun } from "lucide-react"

export default function Home() {
  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="text-center py-12 px-4">
        <div className="max-w-3xl mx-auto">
          <ConfessioLogo size="lg" className="mx-auto mb-6" />
          <h1 className="text-4xl md:text-6xl font-bold gradient-text mb-6">Share Anonymously</h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Express yourself freely in a safe, anonymous environment. Create profiles, join rooms, and connect without
            revealing your identity.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/create-profile">
              <Button size="lg" className="group">
                <Users className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                Create Profile
              </Button>
            </Link>
            <Link href="/create-room">
              <Button variant="outline" size="lg" className="group">
                <Plus className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                Create Room
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Why Choose Confessio?</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="card-hover border-2 border-primary/20 dark:border-primary/30">
              <CardHeader>
                <Shield className="h-8 w-8 text-primary mb-2" />
                <CardTitle>100% Anonymous</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  No email, no password, no personal information required. Your privacy is our priority.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="card-hover border-2 border-primary/20 dark:border-primary/30">
              <CardHeader>
                <MessageSquare className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Real-time Chat</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Instant messaging with reactions and replies. Connect with others in real-time.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="card-hover border-2 border-primary/20 dark:border-primary/30">
              <CardHeader>
                <Users className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Public Rooms</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Join or create public rooms for group discussions on any topic you're passionate about.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Theme Info Section */}
      <section className="py-8">
        <div className="max-w-2xl mx-auto text-center">
          <div className="flex items-center justify-center gap-4 mb-4">
            <Sun className="h-6 w-6 text-yellow-500" />
            <span className="text-lg font-medium">Switch between light and dark themes</span>
            <Moon className="h-6 w-6 text-blue-500" />
          </div>
          <p className="text-muted-foreground">
            Use the theme toggle in the top navigation to switch between light and dark modes for comfortable browsing.
          </p>
        </div>
      </section>

      {/* Rooms Section */}
      <section className="py-12">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Public Rooms</h2>
            <Link href="/create-room">
              <Button className="group">
                <Plus className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform" />
                Create Room
              </Button>
            </Link>
          </div>
          <RoomList />
        </div>
      </section>
    </div>
  )
}
