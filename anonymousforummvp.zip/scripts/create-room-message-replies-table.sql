-- Create room_message_replies table
CREATE TABLE IF NOT EXISTS room_message_replies (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  room_message_id UUID NOT NULL REFERENCES room_messages(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  sender_nickname VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_room_message_replies_room_message_id ON room_message_replies(room_message_id);
CREATE INDEX IF NOT EXISTS idx_room_message_replies_created_at ON room_message_replies(created_at);

-- Enable RLS (Row Level Security)
ALTER TABLE room_message_replies ENABLE ROW LEVEL SECURITY;

-- Create policy to allow all operations (since this is an anonymous platform)
CREATE POLICY "Allow all operations on room_message_replies" ON room_message_replies
  FOR ALL USING (true) WITH CHECK (true);
