-- Add image_url column to replies table for both profile and room message replies
ALTER TABLE replies ADD COLUMN IF NOT EXISTS image_url TEXT;

-- Add comment to document the column
COMMENT ON COLUMN replies.image_url IS 'Base64 encoded image data or URL for reply attachments';

-- Create index for better performance when querying replies with images
CREATE INDEX IF NOT EXISTS idx_replies_image_url ON replies(image_url) WHERE image_url IS NOT NULL;
