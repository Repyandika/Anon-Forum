"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"

interface Reaction {
  id: string
  reaction_type: string
  created_at: string
}

interface MessageReactionsProps {
  messageId: string
  messageType: "profile" | "room"
}

const REACTION_EMOJIS = {
  like: "👍",
  love: "❤️",
  laugh: "😂",
  wow: "😮",
  sad: "😢",
  angry: "😡",
}

export function MessageReactions({ messageId, messageType }: MessageReactionsProps) {
  const [reactions, setReactions] = useState<Reaction[]>([])
  const [loading, setLoading] = useState(true)
  const [showReactionPicker, setShowReactionPicker] = useState(false)
  const [addingReaction, setAddingReaction] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    fetchReactions()
  }, [messageId])

  const fetchReactions = async () => {
    try {
      const response = await fetch(`/api/reactions?messageId=${messageId}&messageType=${messageType}`)
      const data = await response.json()

      if (response.ok) {
        setReactions(data)
      }
    } catch (error) {
      console.error("Error fetching reactions:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleReaction = async (reactionType: string) => {
    // Optimistic update - add reaction immediately
    const optimisticReaction: Reaction = {
      id: `temp-${Date.now()}`,
      reaction_type: reactionType,
      created_at: new Date().toISOString(),
    }

    setReactions((prev) => [...prev, optimisticReaction])
    setShowReactionPicker(false)
    setAddingReaction(reactionType)

    try {
      const response = await fetch("/api/reactions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messageId,
          messageType,
          reactionType,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to add reaction")
      }

      // Replace optimistic reaction with real one
      setReactions((prev) => prev.map((reaction) => (reaction.id === optimisticReaction.id ? data : reaction)))
    } catch (error) {
      console.error("Error adding reaction:", error)

      // Rollback optimistic update
      setReactions((prev) => prev.filter((reaction) => reaction.id !== optimisticReaction.id))

      toast({
        title: "Error",
        description: "Failed to add reaction",
        variant: "destructive",
      })
    } finally {
      setAddingReaction(null)
    }
  }

  const getReactionCount = (reactionType: string) => {
    return reactions.filter((r) => r.reaction_type === reactionType).length
  }

  const getTotalReactions = () => {
    return reactions.length
  }

  const getTopReactions = () => {
    const counts: { [key: string]: number } = {}
    reactions.forEach((r) => {
      counts[r.reaction_type] = (counts[r.reaction_type] || 0) + 1
    })

    return Object.entries(counts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 3)
      .map(([type]) => type)
  }

  if (loading) {
    return <div className="text-xs text-muted-foreground animate-pulse">Loading...</div>
  }

  const totalReactions = getTotalReactions()
  const topReactions = getTopReactions()

  return (
    <div className="flex items-center gap-2 mt-2">
      {/* Reaction Display */}
      {totalReactions > 0 && (
        <div className="flex items-center gap-1 text-sm text-muted-foreground bg-muted/50 rounded-full px-2 py-1 animate-fade-in">
          <div className="flex -space-x-1">
            {topReactions.map((type) => (
              <span key={type} className="text-xs bg-background rounded-full border border-background">
                {REACTION_EMOJIS[type as keyof typeof REACTION_EMOJIS]}
              </span>
            ))}
          </div>
          <span className="text-xs font-medium">{totalReactions}</span>
        </div>
      )}

      {/* Reaction Button */}
      <div className="relative">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowReactionPicker(!showReactionPicker)}
          className="h-7 px-2 text-xs hover:bg-muted/50 transition-all duration-200"
          disabled={!!addingReaction}
        >
          {addingReaction ? (
            <span className="animate-spin">⏳</span>
          ) : (
            <span className="hover:scale-110 transition-transform">👍</span>
          )}
          <span className="ml-1">React</span>
        </Button>

        {/* Reaction Picker */}
        {showReactionPicker && (
          <div className="absolute bottom-full left-0 mb-2 bg-background border rounded-full shadow-lg p-2 flex gap-1 z-10 animate-slide-in">
            {Object.entries(REACTION_EMOJIS).map(([type, emoji]) => (
              <Button
                key={type}
                variant="ghost"
                size="sm"
                onClick={() => handleReaction(type)}
                className="h-8 w-8 p-0 hover:scale-125 transition-all duration-200 hover:bg-accent"
                title={type}
                disabled={addingReaction === type}
              >
                <span className="text-lg">{emoji}</span>
              </Button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
