"use client"

import { useState, useEffect } from "react"
import { X, Sparkles, Layout, Search, MessageCircle, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function UpdatePopup() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Check if user has already seen this update
    const hasSeenUpdate = localStorage.getItem("confessio-update-v1.2")

    if (!hasSeenUpdate) {
      // Show popup after 2 seconds
      const timer = setTimeout(() => {
        setIsVisible(true)
      }, 2000)

      return () => clearTimeout(timer)
    }
  }, [])

  const handleClose = () => {
    setIsVisible(false)
    localStorage.setItem("confessio-update-v1.2", "seen")
  }

  const handleExplore = () => {
    setIsVisible(false)
    localStorage.setItem("confessio-update-v1.2", "seen")
    // Optionally scroll to rooms section or navigate
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  if (!isVisible) return null

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-background via-background to-accent/10 border-2 border-primary/20 shadow-2xl">
        <CardHeader className="relative pb-4">
          <Button variant="ghost" size="sm" className="absolute right-2 top-2 h-8 w-8 p-0" onClick={handleClose}>
            <X className="h-4 w-4" />
          </Button>

          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg">
              <Sparkles className="h-6 w-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                What's New?
              </CardTitle>
              <Badge variant="secondary" className="mt-1">
                New Improvements
              </Badge>
            </div>
          </div>

          <CardDescription className="text-base">
            We've made some exciting improvements to enhance your anonymous forum experience!
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Feature Cards */}
          <div className="grid gap-4">
            <div className="flex gap-4 p-4 rounded-lg bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border border-purple-200 dark:border-purple-800">
              <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                <Layout className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <h4 className="font-semibold text-purple-900 dark:text-purple-100">Enhanced Room Layout</h4>
                <p className="text-sm text-purple-700 dark:text-purple-300">
                  Beautiful grid layout with hover effects and better visual hierarchy for browsing rooms.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-4 rounded-lg bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20 border border-blue-200 dark:border-blue-800">
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <Search className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h4 className="font-semibold text-blue-900 dark:text-blue-100">Improved Search Experience</h4>
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  Enhanced search functionality with better visual feedback and clear options.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-4 rounded-lg bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 border border-green-200 dark:border-green-800">
              <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                <MessageCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <h4 className="font-semibold text-green-900 dark:text-green-100">Better Message Threading</h4>
                <p className="text-sm text-green-700 dark:text-green-300">
                  Visual thread lines and improved reply system for better conversation flow.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-4 rounded-lg bg-gradient-to-r from-orange-50 to-yellow-50 dark:from-orange-950/20 dark:to-yellow-950/20 border border-orange-200 dark:border-orange-800">
              <div className="p-2 bg-orange-100 dark:bg-orange-900 rounded-lg">
                <Calendar className="h-5 w-5 text-orange-600 dark:text-orange-400" />
              </div>
              <div>
                <h4 className="font-semibold text-orange-900 dark:text-orange-100">Simplified Navigation</h4>
                <p className="text-sm text-orange-700 dark:text-orange-300">
                  Clean header with calendar integration and streamlined user interface.
                </p>
              </div>
            </div>
          </div>

          {/* Community First Section */}
          <div className="border-t pt-4">
            <h3 className="font-semibold mb-2 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              Community First
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              These improvements focus on making your anonymous conversations more engaging and accessible. We're
              committed to providing a safe space where everyone can share their thoughts freely.
            </p>

            <div className="bg-muted/50 rounded-lg p-3">
              <h4 className="font-medium text-sm mb-2">New Features:</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Responsive grid layout for all screen sizes</li>
                <li>• Enhanced visual feedback for user interactions</li>
                <li>• Improved accessibility and keyboard navigation</li>
                <li>• Better error handling and loading states</li>
              </ul>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button variant="outline" onClick={handleClose} className="flex-1 bg-transparent">
              Maybe Later
            </Button>
            <Button
              onClick={handleExplore}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              Explore Now
            </Button>
          </div>

          {/* Version Info */}
          <div className="text-center pt-2 border-t">
            <p className="text-xs text-muted-foreground">Version 1.2 • Released January 2025</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
