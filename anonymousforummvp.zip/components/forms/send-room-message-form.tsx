"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Send, ImageIcon, X, Loader2 } from "lucide-react"

interface SendRoomMessageFormProps {
  roomId: string
  onMessageSent?: () => void
}

export function SendRoomMessageForm({ roomId, onMessageSent }: SendRoomMessageFormProps) {
  const [content, setContent] = useState("")
  const [senderUsername, setSenderUsername] = useState("")
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const { toast } = useToast()

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        // 5MB limit
        toast({
          title: "Error",
          description: "Image size must be less than 5MB",
          variant: "destructive",
        })
        return
      }

      setImageFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const removeImage = () => {
    setImageFile(null)
    setImagePreview(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!content.trim() && !imageFile) {
      toast({
        title: "Error",
        description: "Please enter a message or select an image",
        variant: "destructive",
      })
      return
    }

    setSubmitting(true)

    try {
      let imageUrl = null

      // Convert image to base64 if present
      if (imageFile) {
        const reader = new FileReader()
        imageUrl = await new Promise<string>((resolve) => {
          reader.onload = (e) => resolve(e.target?.result as string)
          reader.readAsDataURL(imageFile)
        })
      }

      const response = await fetch("/api/room-messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          roomId,
          content: content.trim() || null,
          senderUsername: senderUsername.trim() || null,
          imageUrl,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to send message")
      }

      // Clear form
      setContent("")
      setSenderUsername("")
      setImageFile(null)
      setImagePreview(null)

      toast({
        title: "Message sent",
        description: "Your message has been posted to the room",
      })

      // Notify parent component
      onMessageSent?.()
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Send Message</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            placeholder="Your username (optional)"
            value={senderUsername}
            onChange={(e) => setSenderUsername(e.target.value)}
            disabled={submitting}
          />

          <Textarea
            placeholder="Write your message..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[100px] resize-none"
            disabled={submitting}
          />

          {/* Image Preview */}
          {imagePreview && (
            <div className="relative">
              <img
                src={imagePreview || "/placeholder.svg"}
                alt="Preview"
                className="max-w-full max-h-48 rounded-lg border object-contain"
              />
              <Button
                type="button"
                variant="destructive"
                size="sm"
                className="absolute top-2 right-2"
                onClick={removeImage}
                disabled={submitting}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}

          <div className="flex gap-2">
            <div className="flex-1">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
                id="image-upload"
                disabled={submitting}
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => document.getElementById("image-upload")?.click()}
                disabled={submitting}
                className="w-full"
              >
                <ImageIcon className="h-4 w-4 mr-2" />
                Add Image
              </Button>
            </div>
            <Button type="submit" disabled={submitting || (!content.trim() && !imageFile)} className="px-8">
              {submitting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2" />}
              {submitting ? "Sending..." : "Send"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
