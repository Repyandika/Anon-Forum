"use client"

import type React from "react"

import Link from "next/link"
import { ConfessioLogo } from "./confessio-logo"
import { Button } from "@/components/ui/button"
import {
  Heart,
  Coffee,
  Instagram,
  Linkedin,
  Github,
  Users,
  Calendar,
  Code,
  Shield,
  Database,
  BookOpen,
  Palette,
} from "lucide-react"

/* -------------------------------------------------------------------------- */
/*                                  CONTENT                                   */
/* -------------------------------------------------------------------------- */

const socialLinks = [
  {
    name: "Instagram",
    icon: Instagram,
    href: "https://www.instagram.com/confesiouniverse?igsh=cmFwcW8xaGY0aXA0",
    color: "hover:text-pink-400",
  },
]

type Dev = {
  name: string
  role: string
  instagram: string
  linkedin: string
  github: string
  description: string
  responsibilities: string[]
  specialization: string
  gradient: string
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>
}

const developerProfiles: Dev[] = [
  {
    name: "Septa Repyandika",
    role: "Project Leader",
    instagram: "https://instagram.com/srdhika_04",
    linkedin: "https://linkedin.com/in/septa-dika",
    github: "https://github.com/Repyandika",
    description: "Memimpin koordinasi pengembangan dan mengimplementasikan fitur utama website.",
    responsibilities: [
      "Frontend & Backend Development",
      "Create Profile & Public Room",
      "Interaksi UI",
      "Struktur Data & Fungsionalitas",
    ],
    specialization: "Full-Stack Development",
    gradient: "from-blue-500 to-purple-600",
    icon: Users,
  },
  {
    name: "Faiz Abhinaya",
    role: "Backend Developer & System Administrator",
    instagram: "https://www.instagram.com/pais_izz/",
    linkedin: "https://www.linkedin.com/in/faiz-abhinaya-7b6095200/",
    github: "https://github.com/izzq8",
    description: "Mengembangkan admin panel dan mengelola sistem backend platform.",
    responsibilities: [
      "Admin Panel Development",
      "API Backend Management",
      "Sistem Kontrol Akses",
      "Kestabilan Server",
    ],
    specialization: "Backend & SysAdmin",
    gradient: "from-green-500 to-teal-600",
    icon: Shield,
  },
  {
    name: "Raflie Aditya",
    role: "Technical Support – Database & Backend",
    instagram: "https://instagram.com/addxcted24/",
    linkedin: "https://linkedin.com/in/raflie-aditya-5a58a8285",
    github: "https://github.com/Arafle2828",
    description: "Mendukung pengaturan database dan pengembangan backend.",
    responsibilities: [
      "Database Structure Setup",
      "Backend Development Support",
      "Data Security & Storage",
      "Anonymous Data Management",
    ],
    specialization: "Database Management",
    gradient: "from-orange-500 to-red-600",
    icon: Database,
  },
  {
    name: "Dafa Naufal",
    role: "Technical Support – Dokumentasi & Pengujian",
    instagram: "https://www.instagram.com/daffaa_dna/",
    linkedin: "https://www.linkedin.com/in/daffa-naufal-abdillah-2b97aa285/",
    github: "https://github.com/faaDNA",
    description: "Menyusun dokumentasi teknis dan melakukan pengujian aplikasi.",
    responsibilities: ["Dokumentasi Teknis", "Flowchart & ERD", "Feature Testing", "Project Evaluation"],
    specialization: "Documentation & QA",
    gradient: "from-purple-500 to-pink-600",
    icon: BookOpen,
  },
  {
    name: "Khairul Ramadhan",
    role: "Technical Support – UI/UX & Konten",
    instagram: "https://www.instagram.com/khrl_.09?igsh=NmY0Nmp4dWljODk0",
    linkedin: "https://www.linkedin.com/in/khairul-ramadhan-s-a437a9285",
    github: "https://github.com/kairu09",
    description: "Memberikan masukan desain UI/UX dan menyusun konten tampilan.",
    responsibilities: [
      "UI/UX Design Input",
      "Interface Content",
      "User Experience Feedback",
      "Text & Notification Setup",
    ],
    specialization: "UI/UX & Content",
    gradient: "from-cyan-500 to-blue-600",
    icon: Palette,
  },
]

/* -------------------------------------------------------------------------- */
/*                               REACT COMPONENT                              */
/* -------------------------------------------------------------------------- */

export function Footer() {
  return (
    <footer className="bg-gradient-to-r from-background via-accent/20 to-background border-t mt-16">
      {/* ------------------------------------------------------------------ */}
      {/*                          TOP 3-COLUMN AREA                         */}
      {/* ------------------------------------------------------------------ */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2 space-y-4">
            <ConfessioLogo size="md" />
            <p className="text-muted-foreground max-w-md leading-relaxed">
              Platform aman untuk berbagi pesan secara anonim. Tempat di mana suara Anda didengar tanpa mengungkap
              identitas.
            </p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>Dibuat dengan</span>
              <Heart className="h-5 w-5 text-red-500 animate-pulse" />
              <span>untuk komunitas yang aman</span>
            </div>
          </div>

          {/* Quick links */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">Tautan Cepat</h3>
            {[
              { href: "/", label: "Beranda" },
              { href: "/create-profile", label: "Buat Profil" },
              { href: "/create-room", label: "Buat Room" },
              { href: "/privacy", label: "Kebijakan Privasi" },
              { href: "/terms", label: "Syarat Layanan" },
              { href: "/about", label: "Tentang Kami" },
              { href: "/help", label: "Bantuan" },
            ].map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="block text-muted-foreground hover:text-primary transition-colors"
              >
                {l.label}
              </Link>
            ))}
          </div>

          {/* Support */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">Dukung Kami</h3>
            <p className="text-sm text-muted-foreground">Bantu kami menjaga platform ini tetap gratis dan aman</p>
            <div className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start bg-transparent" asChild>
                <Link href="https://trakteer.id/confesio">
                  <Coffee className="h-4 w-4 mr-2" />
                  Trakteer
                </Link>
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start bg-transparent" asChild>
                <Link href="https://saweria.co/confesiouniverse">
                  <Heart className="h-4 w-4 mr-2" />
                  Saweria
                </Link>
              </Button>
            </div>
          </div>
        </div>

        {/* ------------------------------------------------------------------ */}
        {/*                        DEVELOPER PROFILES                           */}
        {/* ------------------------------------------------------------------ */}
        <div className="border-t mt-12 pt-12">
          {/* Header */}
          <div className="text-center mb-10">
            <h3 className="text-2xl font-bold flex justify-center items-center gap-2">
              <Code className="h-6 w-6 text-primary" />
              Tim Pengembang Confesio
            </h3>
            <p className="text-muted-foreground text-sm">
              Mahasiswa yang mengembangkan platform ini sebagai tugas akhir mata kuliah
            </p>
          </div>

          {/* Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {developerProfiles.map((dev) => (
              <article
                key={dev.name}
                className="relative overflow-hidden rounded-xl border border-muted bg-gradient-to-br from-background to-muted/20 p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
              >
                {/* subtle gradient flair */}
                <span
                  className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${dev.gradient} opacity-0 transition-opacity duration-300 hover:opacity-10`}
                />

                {/* Top line */}
                <header className="relative z-10 mb-4 flex items-start justify-between">
                  <div className="flex gap-3">
                    <div
                      className={`flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br ${dev.gradient}`}
                    >
                      <dev.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg">{dev.name}</h4>
                      <p className="text-sm text-muted-foreground">{dev.role}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    2024
                  </div>
                </header>

                {/* Description */}
                <p className="relative z-10 mb-4 text-sm text-muted-foreground">{dev.description}</p>

                {/* Specialization badge */}
                <span
                  className={`relative z-10 inline-block rounded-full bg-gradient-to-r ${dev.gradient} px-3 py-1 text-xs font-medium text-white shadow`}
                >
                  {dev.specialization}
                </span>

                {/* Responsibilities */}
                <div className="relative z-10 mt-4">
                  <h5 className="mb-2 text-sm font-semibold">Tanggung Jawab:</h5>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-xs text-muted-foreground">
                    {dev.responsibilities.map((resp) => (
                      <li key={resp} className="flex gap-2">
                        <span className="mt-1 block h-1.5 w-1.5 flex-shrink-0 rounded-full bg-primary" />
                        {resp}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Socials */}
                <footer className="relative z-10 mt-6 flex items-center gap-2 border-t border-muted pt-3">
                  <span className="text-xs text-muted-foreground">Connect:</span>
                  <SocialButton
                    href={dev.instagram}
                    label={`${dev.name} Instagram`}
                    icon={Instagram}
                    hover="hover:text-pink-500 hover:bg-pink-500/10"
                  />
                  <SocialButton
                    href={dev.linkedin}
                    label={`${dev.name} LinkedIn`}
                    icon={Linkedin}
                    hover="hover:text-blue-600 hover:bg-blue-600/10"
                  />
                  <SocialButton
                    href={dev.github}
                    label={`${dev.name} GitHub`}
                    icon={Github}
                    hover="hover:text-gray-600 hover:bg-gray-600/10"
                  />
                </footer>
              </article>
            ))}
          </div>
        </div>
      </div>{" "}
      {/* closes the TOP-LEVEL container */}
      {/* ------------------------------------------------------------------ */}
      {/*                         FOOTER BOTTOM BAR                          */}
      {/* ------------------------------------------------------------------ */}
      <div className="border-t py-6">
        <div className="container mx-auto flex flex-col items-center justify-between gap-4 px-4 md:flex-row">
          {/* Social */}
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Ikuti kami:</span>
            {socialLinks.map((s) => (
              <Link
                key={s.name}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                className={`transition-transform duration-200 hover:scale-110 ${s.color}`}
                aria-label={s.name}
              >
                <s.icon className="h-5 w-5 text-muted-foreground" />
              </Link>
            ))}
          </div>

          {/* Legal */}
          <div className="flex flex-col items-center gap-4 text-sm text-muted-foreground md:flex-row">
            <div className="flex items-center gap-4">
              <Link href="/privacy" className="hover:text-primary">
                Kebijakan Privasi
              </Link>
              <Link href="/terms" className="hover:text-primary">
                Syarat Layanan
              </Link>
              <Link href="/help" className="hover:text-primary">
                Bantuan
              </Link>
            </div>
            <p>&copy; 2025&nbsp;Confesio. Semua hak dilindungi.</p>
          </div>
        </div>
      </div>
    </footer>
  )
}

/* -------------------------------------------------------------------------- */
/*                          SMALL REUSABLE BUTTON                             */
/* -------------------------------------------------------------------------- */

type SocialButtonProps = {
  href: string
  label: string
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>
  hover: string
}

function SocialButton({ href, label, icon: Icon, hover }: SocialButtonProps) {
  return (
    <Button
      asChild
      variant="ghost"
      size="sm"
      className={`h-8 w-8 p-0 transition-transform duration-200 hover:scale-110 ${hover}`}
    >
      <Link href={href} target="_blank" rel="noopener noreferrer" aria-label={label}>
        <Icon className="h-4 w-4" />
      </Link>
    </Button>
  )
}
