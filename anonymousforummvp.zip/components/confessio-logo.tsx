"use client"

interface ConfessioLogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export function ConfessioLogo({ className = "", size = "md" }: ConfessioLogoProps) {
  const sizeClasses = {
    sm: "h-8",
    md: "h-10",
    lg: "h-12",
  }

  const textSizes = {
    sm: "text-xl",
    md: "text-2xl",
    lg: "text-3xl",
  }

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Logo Icon */}
      <div className={`${sizeClasses[size]} aspect-square relative`}>
        <svg viewBox="0 0 40 40" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#8B5CF6" />
              <stop offset="100%" stopColor="#3B82F6" />
            </linearGradient>
          </defs>

          {/* Main chat bubble */}
          <path
            d="M8 12C8 8.68629 10.6863 6 14 6H26C29.3137 6 32 8.68629 32 12V20C32 23.3137 29.3137 26 26 26H18L12 30V26H14C10.6863 26 8 23.3137 8 20V12Z"
            fill="url(#logoGradient)"
            opacity="0.9"
          />

          {/* Inner dots for anonymity */}
          <circle cx="16" cy="16" r="1.5" fill="white" opacity="0.9" />
          <circle cx="20" cy="16" r="1.5" fill="white" opacity="0.9" />
          <circle cx="24" cy="16" r="1.5" fill="white" opacity="0.9" />
        </svg>
      </div>

      {/* Logo Text */}
      <span
        className={`font-bold ${textSizes[size]} bg-gradient-to-r from-purple-600 to-blue-600 dark:from-purple-400 dark:to-blue-400 bg-clip-text text-transparent transition-all duration-300`}
      >
        Confesio
      </span>
    </div>
  )
}
