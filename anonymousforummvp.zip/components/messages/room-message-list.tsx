"use client"

import { useState, useEffect } from "react"
import { formatDate } from "@/lib/utils"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MessageReactions } from "@/components/reactions/message-reactions"
import { MessageReplies } from "@/components/replies/message-replies"
import { RefreshCw, User, Clock, ChevronLeft, ChevronRight } from "lucide-react"
import { useCache } from "@/hooks/use-cache"

interface RoomMessage {
  id: string
  content: string | null
  sender_username: string | null
  image_url: string | null
  created_at: string
}

interface RoomMessageListProps {
  roomId: string
  refreshTrigger?: number
}

const MESSAGES_PER_PAGE = 10

export function RoomMessageList({ roomId, refreshTrigger }: RoomMessageListProps) {
  const [messages, setMessages] = useState<RoomMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [totalMessages, setTotalMessages] = useState(0)
  const [error, setError] = useState<string | null>(null)

  const cache = useCache<{ messages: RoomMessage[]; totalPages: number; totalMessages: number }>({
    defaultTTL: 1 * 60 * 1000, // 1 minute for room messages
  })

  const fetchMessages = async (page = 1, useCache = true) => {
    const cacheKey = `room-messages-${roomId}-${page}`
    setError(null)

    // Check cache first
    if (useCache) {
      const cachedData = cache.get(cacheKey)
      if (cachedData) {
        setMessages(cachedData.messages)
        setTotalPages(cachedData.totalPages)
        setTotalMessages(cachedData.totalMessages)
        setLoading(false)
        return
      }
    }

    try {
      const response = await fetch(
        `/api/room-messages?roomId=${encodeURIComponent(roomId)}&page=${page}&limit=${MESSAGES_PER_PAGE}`,
      )

      if (!response.ok) {
        const errorText = await response.text()
        console.error("API Error:", errorText)
        throw new Error(`HTTP ${response.status}: ${errorText}`)
      }

      const data = await response.json()

      setMessages(data.messages || [])
      setTotalPages(data.totalPages || 1)
      setTotalMessages(data.totalMessages || 0)

      // Cache the results
      cache.set(cacheKey, {
        messages: data.messages || [],
        totalPages: data.totalPages || 1,
        totalMessages: data.totalMessages || 0,
      })
    } catch (error) {
      console.error("Error fetching room messages:", error)
      setError(error instanceof Error ? error.message : "Failed to fetch messages")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => {
    fetchMessages(currentPage)
  }, [roomId, currentPage, refreshTrigger])

  const handleRefresh = () => {
    setRefreshing(true)
    // Clear cache for current page
    const cacheKey = `room-messages-${roomId}-${currentPage}`
    cache.remove(cacheKey)
    fetchMessages(currentPage, false)
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    setLoading(true)
  }

  if (loading && !refreshing) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
              <div className="h-4 bg-muted rounded w-1/2"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-destructive mb-4">Error: {error}</p>
          <Button onClick={() => fetchMessages(currentPage, false)} variant="outline">
            Try Again
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header with refresh button */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Messages {totalMessages > 0 && `(${totalMessages})`}</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          disabled={refreshing}
          className="transition-all duration-200 bg-transparent"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing..." : "Refresh"}
        </Button>
      </div>

      {/* Messages */}
      {messages.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            <p>No messages in this room yet. Start the conversation!</p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="space-y-4">
            {messages.map((message, index) => (
              <Card
                key={message.id}
                className="transition-all duration-200 hover:shadow-md animate-slide-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <CardContent className="p-4">
                  <div className="space-y-3">
                    {/* Message Content */}
                    {message.content && <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>}

                    {/* Image */}
                    {message.image_url && (
                      <div className="mt-3">
                        <img
                          src={message.image_url || "/placeholder.svg"}
                          alt="Message attachment"
                          className="max-w-full max-h-96 rounded-lg border object-contain transition-all duration-200 hover:scale-105 cursor-pointer"
                          onClick={() => window.open(message.image_url!, "_blank")}
                        />
                      </div>
                    )}

                    <div className="flex justify-between items-center text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <User className="h-4 w-4" />
                        {message.sender_username || "Anonymous"}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {formatDate(message.created_at)}
                      </span>
                    </div>

                    <div className="border-t pt-3 space-y-2">
                      <MessageReactions messageId={message.id} messageType="room" />
                      <MessageReplies messageId={message.id} messageType="room" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 pt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="transition-all duration-200"
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>

              <div className="flex items-center gap-1">
                {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                  let page: number
                  if (totalPages <= 5) {
                    page = i + 1
                  } else if (currentPage <= 3) {
                    page = i + 1
                  } else if (currentPage >= totalPages - 2) {
                    page = totalPages - 4 + i
                  } else {
                    page = currentPage - 2 + i
                  }

                  return (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "ghost"}
                      size="sm"
                      onClick={() => handlePageChange(page)}
                      className="h-8 w-8 p-0 transition-all duration-200"
                    >
                      {page}
                    </Button>
                  )
                })}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="transition-all duration-200"
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          )}

          {/* Page info */}
          <div className="text-center text-sm text-muted-foreground">
            Page {currentPage} of {totalPages} • {totalMessages} total messages
          </div>
        </>
      )}
    </div>
  )
}
