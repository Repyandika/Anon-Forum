"use client"

import Link from "next/link"
import { ConfessioLogo } from "./confessio-logo"
import { ThemeToggle } from "./theme-toggle"
import { Button } from "@/components/ui/button"
import { Plus, User, Home } from "lucide-react"

export function Navigation() {
  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/create-profile", label: "Create Profile", icon: User },
    { href: "/create-room", label: "Create Room", icon: Plus },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link href="/" className="flex items-center space-x-2">
          <ConfessioLogo size="sm" />
        </Link>

        {/* Navigation - Always visible, responsive */}
        <nav className="flex items-center space-x-2 sm:space-x-4">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <Button variant="ghost" size="sm" className="flex items-center gap-2">
                <item.icon className="h-4 w-4" />
                <span className="hidden sm:inline">{item.label}</span>
              </Button>
            </Link>
          ))}
        </nav>

        {/* Theme Toggle */}
        <div className="flex items-center">
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}
