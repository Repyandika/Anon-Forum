"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { formatDate } from "@/lib/utils"
import { MessageCircle, Send, ChevronDown, ChevronUp, User, Clock, Loader2, ImageIcon, X } from "lucide-react"

interface Reply {
  id: string
  content: string | null
  sender_nickname: string | null
  image_url: string | null
  created_at: string
}

interface MessageRepliesProps {
  messageId: string
  messageType: "profile" | "room"
}

export function MessageReplies({ messageId, messageType }: MessageRepliesProps) {
  const [replies, setReplies] = useState<Reply[]>([])
  const [showReplyForm, setShowReplyForm] = useState(false)
  const [replyContent, setReplyContent] = useState("")
  const [senderNickname, setSenderNickname] = useState("")
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [showAllReplies, setShowAllReplies] = useState(false)
  const [totalReplies, setTotalReplies] = useState(0)
  const { toast } = useToast()

  const fetchReplies = async () => {
    setLoading(true)
    try {
      const response = await fetch(
        `/api/replies?messageId=${encodeURIComponent(messageId)}&messageType=${messageType}&limit=100`,
      )

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`)
      }

      const data = await response.json()
      setReplies(data.replies || [])
      setTotalReplies(data.total || 0)
    } catch (error) {
      console.error("Error fetching replies:", error)
      toast({
        title: "Error",
        description: "Failed to load replies",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchReplies()
  }, [messageId, messageType])

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Error",
          description: "Image size must be less than 5MB",
          variant: "destructive",
        })
        return
      }

      setImageFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const removeImage = () => {
    setImageFile(null)
    setImagePreview(null)
  }

  const handleSubmitReply = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!replyContent.trim() && !imageFile) {
      toast({
        title: "Error",
        description: "Reply cannot be empty",
        variant: "destructive",
      })
      return
    }

    setSubmitting(true)
    const originalContent = replyContent
    const originalNickname = senderNickname

    try {
      let imageUrl = null

      // Convert image to base64 if present
      if (imageFile) {
        const reader = new FileReader()
        imageUrl = await new Promise<string>((resolve) => {
          reader.onload = (e) => resolve(e.target?.result as string)
          reader.readAsDataURL(imageFile)
        })
      }

      // Optimistic update
      const optimisticReply: Reply = {
        id: `temp-${Date.now()}`,
        content: replyContent.trim() || null,
        sender_nickname: senderNickname.trim() || null,
        image_url: imageUrl,
        created_at: new Date().toISOString(),
      }

      setReplies((prev) => [...prev, optimisticReply])
      setTotalReplies((prev) => prev + 1)

      // Clear form immediately
      setReplyContent("")
      setSenderNickname("")
      setImageFile(null)
      setImagePreview(null)
      setShowReplyForm(false)

      const response = await fetch("/api/replies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messageId,
          messageType,
          content: originalContent.trim() || null,
          senderNickname: originalNickname.trim() || null,
          imageUrl,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to send reply")
      }

      const newReply = await response.json()

      // Replace optimistic reply with real one
      setReplies((prev) => prev.map((reply) => (reply.id === optimisticReply.id ? newReply : reply)))

      toast({
        title: "Reply sent",
        description: "Your reply has been posted",
      })
    } catch (error) {
      console.error("Error sending reply:", error)

      // Rollback optimistic update
      setReplies((prev) => prev.filter((reply) => reply.id !== `temp-${Date.now()}`))
      setTotalReplies((prev) => prev - 1)

      // Restore form
      setReplyContent(originalContent)
      setSenderNickname(originalNickname)
      setShowReplyForm(true)

      toast({
        title: "Error",
        description: "Failed to send reply. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const visibleReplies = showAllReplies ? replies : replies.slice(0, 1)
  const hasHiddenReplies = replies.length > 1 && !showAllReplies

  return (
    <div className="space-y-3">
      {/* Reply Button */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setShowReplyForm(!showReplyForm)}
        className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
        disabled={submitting}
      >
        <MessageCircle className="h-3 w-3 mr-1" />
        Reply {totalReplies > 0 && `(${totalReplies})`}
      </Button>

      {/* Reply Form */}
      {showReplyForm && (
        <Card className="border-l-4 border-l-primary/30 animate-slide-in">
          <CardContent className="p-3">
            <form onSubmit={handleSubmitReply} className="space-y-3">
              <Input
                placeholder="Your nickname (optional)"
                value={senderNickname}
                onChange={(e) => setSenderNickname(e.target.value)}
                className="h-8 text-sm"
                disabled={submitting}
              />
              <Textarea
                placeholder="Write a reply..."
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                className="min-h-[60px] text-sm resize-none"
                disabled={submitting}
                autoFocus
              />

              {/* Image Preview */}
              {imagePreview && (
                <div className="relative">
                  <img
                    src={imagePreview || "/placeholder.svg"}
                    alt="Preview"
                    className="max-w-full max-h-32 rounded-lg border object-contain"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="absolute top-1 right-1 h-6 w-6 p-0"
                    onClick={removeImage}
                    disabled={submitting}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              )}

              <div className="flex gap-2">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                  id={`image-upload-${messageId}`}
                  disabled={submitting}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById(`image-upload-${messageId}`)?.click()}
                  disabled={submitting}
                >
                  <ImageIcon className="h-3 w-3 mr-1" />
                  Image
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  disabled={submitting || (!replyContent.trim() && !imageFile)}
                  className="transition-all duration-200"
                >
                  {submitting ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <Send className="h-3 w-3 mr-1" />}
                  {submitting ? "Posting..." : "Post Reply"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setShowReplyForm(false)
                    setReplyContent("")
                    setSenderNickname("")
                    setImageFile(null)
                    setImagePreview(null)
                  }}
                  disabled={submitting}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Replies List */}
      {loading ? (
        <div className="text-xs text-muted-foreground animate-pulse ml-4">Loading replies...</div>
      ) : replies.length > 0 ? (
        <div className="space-y-2">
          {/* Thread Line Container */}
          <div className="relative ml-4">
            {/* Main thread line */}
            <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary/50 via-primary/30 to-transparent rounded-full" />

            <div className="pl-6 space-y-4">
              {visibleReplies.map((reply, index) => (
                <div key={reply.id} className="relative">
                  {/* Thread connector */}
                  <div className="absolute -left-6 top-4 w-5 h-0.5 bg-gradient-to-r from-primary/50 to-primary/20 rounded-full" />

                  {/* Thread node */}
                  <div className="absolute -left-7 top-3.5 w-2 h-2 bg-primary rounded-full border-2 border-background shadow-sm" />

                  <Card
                    className="bg-muted/30 border-muted animate-slide-in hover:shadow-md transition-all duration-200"
                    style={{ animationDelay: `${index * 0.05}s` }}
                  >
                    <CardContent className="p-3">
                      {/* Reply Content */}
                      {reply.content && (
                        <p className="text-sm leading-relaxed mb-2 whitespace-pre-wrap">{reply.content}</p>
                      )}

                      {/* Reply Image */}
                      {reply.image_url && (
                        <div className="mb-2">
                          <img
                            src={reply.image_url || "/placeholder.svg"}
                            alt="Reply attachment"
                            className="max-w-full max-h-48 rounded-lg border object-contain transition-all duration-200 hover:scale-105 cursor-pointer"
                            onClick={() => window.open(reply.image_url!, "_blank")}
                          />
                        </div>
                      )}

                      <div className="flex justify-between items-center text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {reply.sender_nickname || "Anonymous"}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatDate(reply.created_at)}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {/* Show All/Less Buttons */}
          {hasHiddenReplies && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAllReplies(true)}
              className="h-6 px-2 text-xs text-primary hover:text-primary/80 transition-colors ml-4"
            >
              <ChevronDown className="h-3 w-3 mr-1" />
              Show all replies ({totalReplies})
            </Button>
          )}

          {showAllReplies && replies.length > 1 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAllReplies(false)}
              className="h-6 px-2 text-xs text-muted-foreground hover:text-foreground transition-colors ml-4"
            >
              <ChevronUp className="h-3 w-3 mr-1" />
              Show less
            </Button>
          )}
        </div>
      ) : null}
    </div>
  )
}
