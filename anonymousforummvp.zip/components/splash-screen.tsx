"use client"

import { useState, useEffect } from "react"
import { ConfessioLogo } from "./confessio-logo"
import { Shield, MessageCircle, Users, Sparkles } from "lucide-react"

interface SplashScreenProps {
  onComplete: () => void
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const timers: NodeJS.Timeout[] = []

    // Progressive animation sequence
    timers.push(setTimeout(() => setCurrentStep(1), 1000))
    timers.push(setTimeout(() => setCurrentStep(2), 3000))
    timers.push(setTimeout(() => setCurrentStep(3), 5000))
    timers.push(setTimeout(() => setCurrentStep(4), 7000))

    // Fade out and complete
    timers.push(
      setTimeout(() => {
        setIsVisible(false)
        setTimeout(onComplete, 1000)
      }, 9000),
    )

    return () => {
      timers.forEach((timer) => clearTimeout(timer))
    }
  }, [onComplete])

  if (!isVisible) {
    return (
      <div className="fixed inset-0 z-50 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 opacity-0 transition-opacity duration-1000" />
    )
  }

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Floating particles */}
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-purple-400 rounded-full animate-float opacity-60"></div>
        <div
          className="absolute top-3/4 right-1/4 w-1 h-1 bg-blue-400 rounded-full animate-float opacity-40"
          style={{ animationDelay: "2s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/6 w-1.5 h-1.5 bg-indigo-400 rounded-full animate-float opacity-50"
          style={{ animationDelay: "4s" }}
        ></div>

        {/* Gradient orbs */}
        <div className="absolute top-20 right-20 w-32 h-32 bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute bottom-20 left-20 w-48 h-48 bg-gradient-to-r from-blue-600/15 to-indigo-600/15 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "3s" }}
        ></div>
      </div>

      {/* Main Container */}
      <div className="relative h-full flex flex-col">
        {/* Top Section - 40% */}
        <div className="flex-[2] flex items-end justify-center pb-8">
          {currentStep >= 1 && (
            <div className="text-center animate-slide-up-fade">
              <div className="mb-6">
                <h1 className="font-display text-2xl md:text-4xl lg:text-5xl font-bold text-white leading-tight">
                  <span className="animate-text-shimmer">Selamat datang di</span>
                </h1>
                <h2 className="font-display text-3xl md:text-5xl lg:text-6xl font-bold mt-2">
                  <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent animate-text-shimmer">
                    Confesio
                  </span>
                </h2>
              </div>

              <div className="flex justify-center">
                <div className="bg-emerald-500/20 backdrop-blur-sm rounded-full px-6 py-3 border border-emerald-400/30">
                  <div className="flex items-center space-x-3">
                    <Shield className="w-5 h-5 text-emerald-400 animate-pulse" />
                    <span className="text-emerald-300 font-medium font-mono text-sm">Pesan Anda 100% Aman</span>
                    <Sparkles className="w-4 h-4 text-emerald-400 animate-pulse" />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Center Section - 20% */}
        <div className="flex-[1] flex items-center justify-center">
          {currentStep >= 2 && (
            <div className="text-center animate-bounce-in">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 blur-2xl opacity-30 scale-150 animate-glow-pulse"></div>
                <div className="relative bg-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/20 animate-glow-pulse">
                  <ConfessioLogo size="lg" className="filter drop-shadow-2xl" />

                  {currentStep >= 3 && (
                    <div className="mt-6 animate-slide-up-fade">
                      <p className="font-display text-xl md:text-2xl text-blue-200 font-medium mb-4">
                        Tempat Aman Bersuara
                      </p>

                      <div className="grid grid-cols-3 gap-6 max-w-md mx-auto">
                        <div className="text-center group">
                          <div className="w-12 h-12 mx-auto mb-2 bg-purple-500/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <Shield className="w-6 h-6 text-purple-400" />
                          </div>
                          <span className="text-xs text-purple-300 font-medium">Aman</span>
                        </div>

                        <div className="text-center group">
                          <div className="w-12 h-12 mx-auto mb-2 bg-blue-500/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <MessageCircle className="w-6 h-6 text-blue-400" />
                          </div>
                          <span className="text-xs text-blue-300 font-medium">Real-time</span>
                        </div>

                        <div className="text-center group">
                          <div className="w-12 h-12 mx-auto mb-2 bg-indigo-500/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <Users className="w-6 h-6 text-indigo-400" />
                          </div>
                          <span className="text-xs text-indigo-300 font-medium">Komunitas</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Section - 40% */}
        <div className="flex-[2] flex items-start justify-center pt-8">
          {currentStep >= 1 && (
            <div className="text-center space-y-6 animate-slide-up-fade">
              {/* Status Message */}
              <div className="font-mono text-sm text-white/70">
                {currentStep === 1 && (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                    <span>Memuat sistem keamanan...</span>
                  </div>
                )}
                {currentStep === 2 && (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                    <span>Menyiapkan platform...</span>
                  </div>
                )}
                {currentStep === 3 && (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span>Menginisialisasi fitur...</span>
                  </div>
                )}
                {currentStep >= 4 && (
                  <div className="flex items-center justify-center space-x-2">
                    <Sparkles className="w-4 h-4 text-green-400 animate-pulse" />
                    <span className="text-green-400">Siap digunakan!</span>
                  </div>
                )}
              </div>

              {/* Progress Dots */}
              <div className="flex justify-center space-x-3">
                {[1, 2, 3, 4].map((step) => (
                  <div
                    key={step}
                    className={`w-3 h-3 rounded-full transition-all duration-700 ${
                      currentStep >= step
                        ? "bg-gradient-to-r from-purple-400 to-blue-400 scale-110 shadow-lg"
                        : "bg-white/20 scale-100"
                    }`}
                  />
                ))}
              </div>

              {/* Progress Bar */}
              <div className="w-64 h-1 bg-white/10 rounded-full overflow-hidden mx-auto">
                <div
                  className="h-full bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 rounded-full transition-all duration-1000 ease-out"
                  style={{
                    width: `${(currentStep / 4) * 100}%`,
                  }}
                ></div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
