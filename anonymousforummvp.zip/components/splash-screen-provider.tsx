"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { SplashScreen } from "./splash-screen"

interface SplashScreenProviderProps {
  children: React.ReactNode
}

export function SplashScreenProvider({ children }: SplashScreenProviderProps) {
  const [showSplash, setShowSplash] = useState(true)
  const [hasShownSplash, setHasShownSplash] = useState(false)

  useEffect(() => {
    // Check if splash screen has been shown in this session
    const splashShown = sessionStorage.getItem("confesio-splash-shown")
    if (splashShown) {
      setShowSplash(false)
      setHasShownSplash(true)
    }
  }, [])

  const handleSplashComplete = () => {
    setShowSplash(false)
    setHasShownSplash(true)
    sessionStorage.setItem("confesio-splash-shown", "true")
  }

  if (showSplash && !hasShownSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />
  }

  return <>{children}</>
}
